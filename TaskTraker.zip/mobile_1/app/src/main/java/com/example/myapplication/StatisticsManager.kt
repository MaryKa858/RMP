package com.example.myapplication

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import com.opencsv.CSVWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StatisticsManager(private val context: Context) {

    fun showStatistics(activeTasks: List<MainActivity.Task>, completedTasks: List<MainActivity.Task>) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.statistics_dialog, null)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .setPositiveButton("Закрыть", null)
            .create()

        // График выполнения задач
        val completionChart = dialogView.findViewById<PieChart>(R.id.completionChart)
        setupCompletionChart(completionChart, activeTasks.size, completedTasks.size)

        // График по категориям
        val categoryChart = dialogView.findViewById<BarChart>(R.id.categoryChart)
        setupCategoryChart(categoryChart, activeTasks + completedTasks)

        // Кнопки экспорта
        dialogView.findViewById<Button>(R.id.exportCsvButton).setOnClickListener {
            exportToCsv(activeTasks, completedTasks)
            Toast.makeText(context, "Данные экспортированы в CSV", Toast.LENGTH_SHORT).show()
        }

        dialogView.findViewById<Button>(R.id.exportPdfButton).setOnClickListener {
            exportToPdf(activeTasks, completedTasks)
            Toast.makeText(context, "Данные экспортированы в PDF", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    private fun setupCompletionChart(chart: PieChart, activeCount: Int, completedCount: Int) {
        val entries = listOf(
            PieEntry(activeCount.toFloat(), "Активные"),
            PieEntry(completedCount.toFloat(), "Выполненные")
        )

        val dataSet = PieDataSet(entries, "").apply {
            colors = listOf(Color.BLUE, Color.GREEN)
            valueTextColor = Color.WHITE
            valueTextSize = 12f
        }

        chart.data = PieData(dataSet)
        chart.description.isEnabled = false
        chart.legend.isEnabled = true
        chart.setEntryLabelColor(Color.BLACK)
        chart.animateY(1000)
        chart.invalidate()
    }

    private fun setupCategoryChart(chart: BarChart, tasks: List<MainActivity.Task>) {
        val categories = tasks.groupBy { it.category }
        val entries = mutableListOf<BarEntry>()
        val labels = mutableListOf<String>()

        categories.keys.forEachIndexed { index, category ->
            entries.add(BarEntry(index.toFloat(), categories[category]?.size?.toFloat() ?: 0f))
            labels.add(category)
        }

        val dataSet = BarDataSet(entries, "Количество задач").apply {
            color = Color.BLUE
            valueTextColor = Color.BLACK
            valueTextSize = 10f
        }

        val data = BarData(dataSet)
        chart.data = data

        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.granularity = 1f
        chart.xAxis.setDrawGridLines(false)
        chart.axisLeft.setDrawGridLines(false)
        chart.axisRight.isEnabled = false
        chart.animateY(1000)
        chart.invalidate()
    }

    private fun exportToCsv(activeTasks: List<MainActivity.Task>, completedTasks: List<MainActivity.Task>) {
        val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val fileName = "tasks_stat_${dateFormat.format(Date())}.csv"
        val file = File(context.getExternalFilesDir(null), fileName)

        CSVWriter(FileWriter(file)).use { writer ->
            // Заголовки
            writer.writeNext(arrayOf("Название", "Категория", "Приоритет", "Статус", "Дата"))

            // Активные задачи
            activeTasks.forEach { task ->
                writer.writeNext(arrayOf(
                    task.title,
                    task.category,
                    task.priority,
                    "Активная",
                    task.dateTime
                ))
            }

            // Выполненные задачи
            completedTasks.forEach { task ->
                writer.writeNext(arrayOf(
                    task.title,
                    task.category,
                    task.priority,
                    "Выполненная",
                    task.dateTime
                ))
            }
        }
    }

    private fun exportToPdf(activeTasks: List<MainActivity.Task>, completedTasks: List<MainActivity.Task>) {
        val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val fileName = "tasks_stat_${dateFormat.format(Date())}.pdf"
        val file = File(context.getExternalFilesDir(null), fileName)

        PdfDocument(PdfWriter(file)).use { pdfDocument ->
            Document(pdfDocument).use { document ->
                document.add(Paragraph("Статистика задач").setBold().setFontSize(16f))
                document.add(Paragraph(" "))

                // Общая статистика
                document.add(Paragraph("Всего задач: ${activeTasks.size + completedTasks.size}"))
                document.add(Paragraph("Активных: ${activeTasks.size}"))
                document.add(Paragraph("Выполненных: ${completedTasks.size}"))
                document.add(Paragraph(" "))

                // По категориям
                document.add(Paragraph("Распределение по категориям:"))
                (activeTasks + completedTasks)
                    .groupBy { it.category }
                    .forEach { (category, tasks) ->
                        document.add(Paragraph("$category: ${tasks.size} задач"))
                    }
                document.add(Paragraph(" "))

                // Список задач
                document.add(Paragraph("Список всех задач:"))
                activeTasks.forEach { task ->
                    document.add(Paragraph("[Активная] ${task.title} (${task.category}, ${task.priority}) - ${task.dateTime}"))
                }
                completedTasks.forEach { task ->
                    document.add(Paragraph("[Выполненная] ${task.title} (${task.category}, ${task.priority}) - ${task.dateTime}"))
                }
            }
        }
    }
}