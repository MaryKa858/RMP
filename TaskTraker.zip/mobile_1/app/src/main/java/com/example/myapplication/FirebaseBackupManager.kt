package com.example.myapplication
import android.content.Context
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class FirebaseBackupManager(private val context: Context) {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun backupTasks(activeTasks: List<MainActivity.Task>, completedTasks: List<MainActivity.Task>, callback: (Boolean, String) -> Unit) {
        val user = auth.currentUser
        if (user == null) {
            callback(false, "User not authenticated")
            return
        }

        val tasksData = hashMapOf(
            "activeTasks" to activeTasks.map { it.toMap() },
            "completedTasks" to completedTasks.map { it.toMap() },
            "timestamp" to System.currentTimeMillis()
        )

        db.collection("users").document(user.uid).collection("backups").document("latest")
            .set(tasksData)
            .addOnSuccessListener {
                callback(true, "Backup successful")
            }
            .addOnFailureListener { e ->
                callback(false, "Backup failed: ${e.message}")
            }
    }

    fun restoreTasks(callback: (List<MainActivity.Task>, List<MainActivity.Task>) -> Unit) {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(context, "User not authenticated", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("users").document(user.uid).collection("backups").document("latest")
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val activeTasks = (document.get("activeTasks") as? List<HashMap<String, Any>>)?.map { MainActivity.Task.fromMap(it) } ?: emptyList()
                    val completedTasks = (document.get("completedTasks") as? List<HashMap<String, Any>>)?.map { MainActivity.Task.fromMap(it) } ?: emptyList()
                    callback(activeTasks, completedTasks)
                } else {
                    Toast.makeText(context, "No backup found", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Restore failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}