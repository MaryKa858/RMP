package com.example.myapplication

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ListView
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.prolificinteractive.materialcalendarview.CalendarMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.Random



class MainActivity : AppCompatActivity() {
    private lateinit var firebaseBackupManager: FirebaseBackupManager
    private lateinit var searchView: SearchView
    private lateinit var toggleButton: Button
    private lateinit var taskListView: ListView
    private lateinit var statisticsManager: StatisticsManager
    private lateinit var dayTasksListView: ListView
    private var currentCalendarMode = CalendarMode.MONTHS
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())


    companion object {
        const val CHANNEL_ID = "task_reminder_channel"
    }
    data class Task(
        val title: String,
        val description: String?,
        val category: String,
        val priority: String,
        val dateTime: String,
        val repeatMode: String,
        var isCompleted: Boolean = false,
        var notificationEnabled: Boolean = true,
        var reminderTime: String = "5 минут",
        var notificationId: Int = Random().nextInt(10000)
    ) {
        fun toMap(): Map<String, Any?> {
            return mapOf(
                "title" to title,
                "description" to description,
                "category" to category,
                "priority" to priority,
                "dateTime" to dateTime,
                "repeatMode" to repeatMode,
                "isCompleted" to isCompleted,
                "notificationEnabled" to notificationEnabled,
                "reminderTime" to reminderTime,
                "notificationId" to notificationId
            )
        }
        companion object {
            fun fromMap(map: Map<String, Any>): Task {
                return Task(
                    title = map["title"] as String,
                    description = map["description"] as? String,
                    category = map["category"] as String,
                    priority = map["priority"] as String,
                    dateTime = map["dateTime"] as String,
                    repeatMode = map["repeatMode"] as String,
                    isCompleted = map["isCompleted"] as? Boolean ?: false,
                    notificationEnabled = map["notificationEnabled"] as? Boolean ?: true,
                    reminderTime = map["reminderTime"] as? String ?: "5 минут",
                    notificationId = (map["notificationId"] as? Long)?.toInt() ?: Random().nextInt(10000)
                )
            }
        }

    }

    private val activeTasks = mutableListOf<Task>()
    private val completedTasks = mutableListOf<Task>()
    private lateinit var adapter: TaskAdapter
    private var selectedDateTime = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        setupTheme()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        firebaseBackupManager = FirebaseBackupManager(this)
        taskListView = findViewById(R.id.task_list)  // Инициализация после setContentView
        searchView = findViewById(R.id.search_view)
        toggleButton = findViewById(R.id.toggle_button)
        statisticsManager = StatisticsManager(this)
        try {
            FirebaseApp.getInstance()
        } catch (e: IllegalStateException) {
            FirebaseApp.initializeApp(this)
        }
        firebaseBackupManager = FirebaseBackupManager(applicationContext)
        findViewById<Button>(R.id.stats_button).setOnClickListener {
            statisticsManager.showStatistics(activeTasks, completedTasks)
        }
        findViewById<Button>(R.id.backup_button).setOnClickListener {
            backupTasksToFirebase()
        }
        findViewById<Button>(R.id.restore_button).setOnClickListener {
            restoreTasksFromFirebase()
        }

        findViewById<Button>(R.id.theme_button).setOnClickListener {
            toggleTheme()
        }
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterTasks(newText.orEmpty())
                return true
            }
        })

        firebaseBackupManager = FirebaseBackupManager(this)

        findViewById<Button>(R.id.backup_button).setOnClickListener {
            backupTasksToFirebase()
        }

        findViewById<Button>(R.id.restore_button).setOnClickListener {
            restoreTasksFromFirebase()
        }

        createNotificationChannel()

        val taskListView = findViewById<ListView>(R.id.task_list)
        adapter = TaskAdapter(activeTasks)
        taskListView.adapter = adapter

        // Настройка спиннера категорий
        val categorySpinner = findViewById<Spinner>(R.id.category_spinner)
        val categories = arrayOf("Работа", "Дом", "Учёба", "Личное", "Другое")
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)

        // Настройка спиннера приоритетов
        val prioritySpinner = findViewById<Spinner>(R.id.priority_spinner)
        val priorities = arrayOf("Низкий", "Средний", "Высокий")
        prioritySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, priorities)

        // Настройка спиннера повторения
        val repeatSpinner = findViewById<Spinner>(R.id.repeat_spinner)
        val repeatModes = arrayOf("Не повторять", "Ежедневно", "Еженедельно", "Ежемесячно", "Ежегодно")
        repeatSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, repeatModes)

        // Кнопка выбора даты и времени
        val dateButton = findViewById<Button>(R.id.date_button)
        dateButton.setOnClickListener {
            showDateTimePicker()
        }

        // Кнопка добавления задачи
        val addButton = findViewById<Button>(R.id.add_button)
        addButton.setOnClickListener {
            addNewTask()
        }

        // Кнопка переключения между активными и завершёнными задачами
        val toggleButton = findViewById<Button>(R.id.toggle_button)
        toggleButton.setOnClickListener {
            toggleTasksView()
        }
        // В методе onCreate():
        val statsButton = findViewById<Button>(R.id.stats_button)
        if (statsButton == null) {
            Log.e("MainActivity", "Кнопка stats_button не найдена в макете!")
            Toast.makeText(this, "Ошибка инициализации", Toast.LENGTH_SHORT).show()
        }
        statsButton?.setOnClickListener {
            showBasicStatistics()
        }


        dateButton.setOnClickListener { showDateTimePicker() }
        addButton.setOnClickListener { addNewTask() }
        toggleButton.setOnClickListener { toggleTasksView() }
        statsButton.setOnClickListener { showBasicStatistics() }
        statsButton?.setOnClickListener {
            showBasicStatistics()
        }



    }

    private fun toggleTheme() {
        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        when (currentNightMode) {
            Configuration.UI_MODE_NIGHT_NO -> {
                // Переключаем на темную тему
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
            Configuration.UI_MODE_NIGHT_YES -> {
                // Переключаем на светлую тему
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
            else -> {
                // По умолчанию - светлая тема
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
        val sharedPrefs = getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
        val isDarkTheme = sharedPrefs.getBoolean("dark_theme", false)

        // Инвертируем текущее состояние темы
        val newTheme = !isDarkTheme
        sharedPrefs.edit().putBoolean("dark_theme", newTheme).apply()

        // Применяем новую тему
        if (newTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        // Перезапускаем активность для применения темы
        recreate()
    }

    private fun setupTheme() {
        val sharedPrefs = getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
        val isDarkTheme = sharedPrefs.getBoolean("dark_theme", false)

        if (isDarkTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }




    class FirebaseBackupManager(private val context: Context) {
        private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
        private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

        fun backupTasks(activeTasks: List<MainActivity.Task>, completedTasks: List<MainActivity.Task>,
                        callback: (Boolean, String) -> Unit) {
            val user = auth.currentUser
            if (user == null) {
                callback(false, "User not authenticated")
                return
            }

            val tasksData = hashMapOf(
                "activeTasks" to activeTasks.map { it.toMap() },
                "completedTasks" to completedTasks.map { it.toMap() },
                "timestamp" to System.currentTimeMillis()
            )

            db.collection("users").document(user.uid).collection("backups").document("latest")
                .set(tasksData)
                .addOnSuccessListener {
                    callback(true, "Backup successful")
                }
                .addOnFailureListener { e ->
                    callback(false, "Backup failed: ${e.message}")
                }
        }

        fun restoreTasks(callback: (List<MainActivity.Task>, List<MainActivity.Task>) -> Unit) {
            val user = auth.currentUser
            if (user == null) {
                Toast.makeText(context, "User not authenticated", Toast.LENGTH_SHORT).show()
                return
            }

            db.collection("users").document(user.uid).collection("backups").document("latest")
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val activeTasks = (document.get("activeTasks") as? List<HashMap<String, Any>>)
                            ?.map { MainActivity.Task.fromMap(it) } ?: emptyList()
                        val completedTasks = (document.get("completedTasks") as? List<HashMap<String, Any>>)
                            ?.map { MainActivity.Task.fromMap(it) } ?: emptyList()
                        callback(activeTasks, completedTasks)
                    } else {
                        Toast.makeText(context, "No backup found", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Restore failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun filterTasks(query: String) {
        val filteredTasks = if (toggleButton.text == "Показать архив") {
            activeTasks.filter { task ->
                task.title.contains(query, true) ||
                        task.description?.contains(query, true) ?: false ||
                        task.category.contains(query, true) ||
                        task.priority.contains(query, true)
            }
        } else {
            completedTasks.filter { task ->
                task.title.contains(query, true) ||
                        task.description?.contains(query, true) ?: false ||
                        task.category.contains(query, true) ||
                        task.priority.contains(query, true)
            }
        }
        adapter = TaskAdapter(filteredTasks)
        taskListView.adapter = adapter
    }

    private fun backupTasksToFirebase() {
        firebaseBackupManager.backupTasks(activeTasks, completedTasks) { success, message ->
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupThemeToggle() {
        val sharedPrefs = getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
        val isDarkTheme = sharedPrefs.getBoolean("dark_theme", false)

        if (isDarkTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        // Добавьте кнопку переключения темы в меню или в интерфейс
        val themeButton = findViewById<Button>(R.id.theme_button) // Добавьте эту кнопку в layout
        themeButton.setOnClickListener {
            val newTheme = !isDarkTheme
            sharedPrefs.edit().putBoolean("dark_theme", newTheme).apply()
            recreate()
        }
    }

    private fun restoreTasksFromFirebase() {
        AlertDialog.Builder(this)
            .setTitle("Восстановление")
            .setMessage("Текущие задачи будут заменены. Продолжить??")
            .setPositiveButton("Да") { _, _ ->
                firebaseBackupManager.restoreTasks { restoredActive, restoredCompleted ->
                    activeTasks.clear()
                    activeTasks.addAll(restoredActive)
                    completedTasks.clear()
                    completedTasks.addAll(restoredCompleted)
                    adapter = TaskAdapter(activeTasks)
                    findViewById<ListView>(R.id.task_list).adapter = adapter
                    Toast.makeText(this, "Задачи успешно восстановлены", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Нет", null)
            .show()
    }

    private fun showBasicStatistics() {
        val statsText = """
        Всего задач: ${activeTasks.size + completedTasks.size}
        Активных: ${activeTasks.size}
        Завершенных: ${completedTasks.size}
    """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Статистика")
            .setMessage(statsText)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Напоминания о задачах"
            val descriptionText = "Уведомления о предстоящих задачах"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }


    }

    private inner class TaskAdapter(private val tasks: List<Task>) : BaseAdapter() {
        override fun getCount(): Int = tasks.size
        override fun getItem(position: Int): Any = tasks[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: LayoutInflater.from(parent?.context)
                .inflate(R.layout.task_item, parent, false)

            val task = tasks[position]
            val textView = view.findViewById<TextView>(R.id.task_text)
            val checkBox = view.findViewById<CheckBox>(R.id.task_checkbox)

            textView.text = "${task.title} (${task.category}, ${task.priority}, ${task.dateTime})" +
                    if (task.repeatMode != "Не повторять") " [${task.repeatMode}]" else ""

            checkBox.isChecked = task.isCompleted
            checkBox.setOnCheckedChangeListener { _, isChecked ->
                task.isCompleted = isChecked
                if (isChecked) {
                    (tasks as MutableList).remove(task)
                    completedTasks.add(task)
                    adapter = TaskAdapter(activeTasks)
                    findViewById<ListView>(R.id.task_list).adapter = adapter
                    cancelNotification(task.notificationId)
                    Toast.makeText(this@MainActivity, "Задача перемещена в архив", Toast.LENGTH_SHORT).show()
                }
            }

            view.setOnLongClickListener {
                showNotificationSettingsDialog(task)
                true
            }

            return view
        }
    }

    private fun showNotificationSettingsDialog(task: Task) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.notification_settings, null)
        val notificationCheckbox = dialogView.findViewById<CheckBox>(R.id.notification_checkbox)
        val reminderTimeGroup = dialogView.findViewById<RadioGroup>(R.id.reminder_time_group)

        notificationCheckbox.isChecked = task.notificationEnabled

        when (task.reminderTime) {
            "5 минут" -> reminderTimeGroup.check(R.id.reminder_5min)
            "1 час" -> reminderTimeGroup.check(R.id.reminder_1hour)
            "1 день" -> reminderTimeGroup.check(R.id.reminder_1day)
        }

        AlertDialog.Builder(this)
            .setTitle("Настройки уведомлений")
            .setView(dialogView)
            .setPositiveButton("Сохранить") { _, _ ->
                task.notificationEnabled = notificationCheckbox.isChecked

                when (reminderTimeGroup.checkedRadioButtonId) {
                    R.id.reminder_5min -> task.reminderTime = "5 минут"
                    R.id.reminder_1hour -> task.reminderTime = "1 час"
                    R.id.reminder_1day -> task.reminderTime = "1 день"
                }

                scheduleNotification(task)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun scheduleNotification(task: Task) {
        if (!task.notificationEnabled) {
            cancelNotification(task.notificationId)
            return
        }

        try {
            val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
            val taskTime = dateFormat.parse(task.dateTime)?.time ?: return
            val calendar = Calendar.getInstance().apply { timeInMillis = taskTime }

            when (task.reminderTime) {
                "5 минут" -> calendar.add(Calendar.MINUTE, -5)
                "1 час" -> calendar.add(Calendar.HOUR_OF_DAY, -1)
                "1 день" -> calendar.add(Calendar.DAY_OF_YEAR, -1)
            }

            val notificationTime = calendar.timeInMillis
            val currentTime = System.currentTimeMillis()

            if (notificationTime <= currentTime) return

            val intent = Intent(this, NotificationReceiver::class.java).apply {
                putExtra("title", task.title)
                putExtra("message", "Напоминание: ${task.title} (${task.dateTime})")
                putExtra("notificationId", task.notificationId)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                this,
                task.notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alarmManager = ContextCompat.getSystemService(
                this,
                AlarmManager::class.java
            ) as AlarmManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    notificationTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    notificationTime,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun cancelNotification(notificationId: Int) {
        val alarmManager = ContextCompat.getSystemService(
            this,
            AlarmManager::class.java
        ) as AlarmManager
        val intent = Intent(this, NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    private fun showDateTimePicker() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, day ->
                val timePicker = TimePickerDialog(
                    this,
                    { _, hour, minute ->
                        calendar.set(year, month, day, hour, minute)
                        val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
                        selectedDateTime = dateFormat.format(calendar.time)
                        Toast.makeText(this, "Выбрано: $selectedDateTime", Toast.LENGTH_SHORT).show()
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    true
                )
                timePicker.show()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.show()
    }

    private fun addNewTask() {
        val title = findViewById<EditText>(R.id.task_title).text.toString().trim()
        if (title.isEmpty()) {
            Toast.makeText(this, "Введите название задачи", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedDateTime.isEmpty()) {
            Toast.makeText(this, "Выберите дату и время", Toast.LENGTH_SHORT).show()
            return
        }

        val description = findViewById<EditText>(R.id.task_description).text.toString().trim()
        val category = findViewById<Spinner>(R.id.category_spinner).selectedItem.toString()
        val priority = findViewById<Spinner>(R.id.priority_spinner).selectedItem.toString()
        val repeatMode = findViewById<Spinner>(R.id.repeat_spinner).selectedItem.toString()

        val newTask = Task(title, description, category, priority, selectedDateTime, repeatMode)
        activeTasks.add(newTask)
        scheduleNotification(newTask)
        adapter = TaskAdapter(activeTasks)
        findViewById<ListView>(R.id.task_list).adapter = adapter

        // Очистка полей
        findViewById<EditText>(R.id.task_title).text.clear()
        findViewById<EditText>(R.id.task_description).text.clear()
        selectedDateTime = ""
    }

    private fun toggleTasksView() {
        val toggleButton = findViewById<Button>(R.id.toggle_button)
        if (toggleButton.text == "Показать архив") {
            adapter = TaskAdapter(completedTasks)
            findViewById<ListView>(R.id.task_list).adapter = adapter
            toggleButton.text = "Показать активные"
            if (completedTasks.isEmpty()) {
                Toast.makeText(this, "Архив пуст", Toast.LENGTH_SHORT).show()
            }
        } else {
            adapter = TaskAdapter(activeTasks)
            findViewById<ListView>(R.id.task_list).adapter = adapter
            toggleButton.text = "Показать архив"
        }
    }

}