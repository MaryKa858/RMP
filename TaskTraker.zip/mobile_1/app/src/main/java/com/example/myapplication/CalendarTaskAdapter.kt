package com.example.myapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class CalendarTaskAdapter(
    context: Context,
    private val tasks: List<MainActivity.Task>  // Указываем полный путь к классу Task
) : ArrayAdapter<MainActivity.Task>(
    context,
    android.R.layout.simple_list_item_1,
    tasks
) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)

        val task = getItem(position)
        val textView = view.findViewById<TextView>(android.R.id.text1)

        textView.text = "${task?.title} (${task?.priority})"
        return view
    }
}