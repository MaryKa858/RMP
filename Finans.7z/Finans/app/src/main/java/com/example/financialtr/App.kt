package com.example.financialtr

import android.app.Application
import com.example.financialtr.data.AppDatabase
import com.example.financialtr.data.DatabaseInitializer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class App : Application(){
    override fun onCreate() {
        super.onCreate()

        val db = AppDatabase.getDatabase(this)

        CoroutineScope(Dispatchers.IO).launch {
            DatabaseInitializer(db).initData()
        }
    }
}