package com.example.financialtr.views

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.financialtr.R
import com.example.financialtr.viewModels.TransactionViewModel
import kotlin.getValue

class HomeScreen : AppCompatActivity() {
    private val viewModel: TransactionViewModel by viewModels()
    private lateinit var incomeTextView: TextView
    private lateinit var expensesTextView: TextView
    private lateinit var balanceTextView: TextView
    private lateinit var addTransaction: Button
    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)

        incomeTextView = findViewById(R.id.income)
        expensesTextView = findViewById(R.id.expenses)
        balanceTextView = findViewById(R.id.balance)
        addTransaction = findViewById<Button>(R.id.btnAddTransaction)

        sharedPref = getSharedPreferences("auth", MODE_PRIVATE)

        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val userId = getUserId()
        if (userId == -1) {
            Toast.makeText(this, "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        addTransaction.setOnClickListener {
            startActivity(Intent(this, AddTransaction::class.java))
            finish()
        }

        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<Button>(R.id.transactionsButton).setOnClickListener {
            startActivity(Intent(this, TransactionsActivity::class.java))
        }

        findViewById<Button>(R.id.statsButton).setOnClickListener {
            startActivity(Intent(this, StatisticsActivity::class.java))
        }

        setupObservers(userId)
    }

    private fun getUserId(): Int {
        return sharedPref.getInt("user_id", -1)
    }

    private fun setupObservers(userId: Int) {
        viewModel.loadAmounts(userId)

        viewModel.amounts.observe(this) { amounts ->
            if (amounts == null || amounts.size < 2) {
                incomeTextView.text = "0.00"
                expensesTextView.text = "0.00"
                balanceTextView.text = "0.00"
                return@observe
            }

            val income = amounts[0]
            val expense = amounts[1]
            val balance = income - expense

            incomeTextView.text = String.format("%.2f", income)
            expensesTextView.text = String.format("%.2f", expense)
            balanceTextView.text = String.format("%.2f", balance)
        }
    }


}