package com.example.financialtr.data

import androidx.room.TypeConverter
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.data.enums.TransactionType

class Converters {
    @TypeConverter
    fun toTransactionType(ordinal: Int): TransactionType? {
        return TransactionType.fromOrdinal(ordinal)
    }

    @TypeConverter
    fun fromTransactionType(type: TransactionType?): Int? {
        return type?.ordinal
    }

    @TypeConverter
    fun toTransactionCategory(ordinal: Int): TransactionCategory? {
        return TransactionCategory.entries.getOrNull(ordinal)
    }

    @TypeConverter
    fun fromTransactionCategory(category: TransactionCategory): Int {
        return category.ordinal
    }
}