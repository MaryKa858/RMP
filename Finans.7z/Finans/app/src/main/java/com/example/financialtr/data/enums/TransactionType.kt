package com.example.financialtr.data.enums

enum class TransactionType(val title: String) {
    INCOME("Доход"),
    EXPENSE("Расход");

    companion object {
        fun fromOrdinal(ordinal: Int): TransactionType? {
            return values().getOrNull(ordinal)
        }
    }
}