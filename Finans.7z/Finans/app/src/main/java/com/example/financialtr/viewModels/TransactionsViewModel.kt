package com.example.financialtr.viewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.financialtr.data.dao.TransactionDao
import com.example.financialtr.data.entities.Transaction
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.data.enums.TransactionType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class TransactionsViewModel constructor(
    private val transactionDao: TransactionDao,
    private val currentUserId: Int
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _filter = MutableStateFlow<TransactionType?>(null)
    private val _sortOrder = MutableStateFlow(SortOrder.DATE_DESC)
    private val _categoryFilter = MutableStateFlow<String?>(null)

    val transactions: Flow<List<Transaction>> = combine(
        _filter,
        _sortOrder,
        _categoryFilter, _searchQuery
    ) { filter, sortOrder, category, query ->
        transactionDao.getTransactionsByUser(currentUserId).map { transactions ->
            var filtered = transactions.filter { transaction ->
                (filter == null || transaction.type == filter) &&
                        (category == null || transaction.category?.title == category) &&
                        (query.isEmpty() || transaction.comment.contains(query, ignoreCase = true))
            }

            when (sortOrder) {
                SortOrder.DATE_ASC -> filtered.sortedBy { it.date }
                SortOrder.DATE_DESC -> filtered.sortedByDescending { it.date }
            }
        }
    }.flatMapLatest { it }

    fun setFilter(filter: TransactionType?) {
        viewModelScope.launch {
            _filter.emit(filter)
        }
    }

    fun setSortOrder(sortOrder: SortOrder) {
        viewModelScope.launch {
            _sortOrder.emit(sortOrder)
        }
    }

    fun setCategoryFilter(category: String?) {
        viewModelScope.launch {
            _categoryFilter.emit(category)
        }
    }

    fun setSearchQuery(query: String) {
        viewModelScope.launch {
            _searchQuery.emit(query)
        }
    }

    enum class SortOrder {
        DATE_ASC, DATE_DESC
    }
}
