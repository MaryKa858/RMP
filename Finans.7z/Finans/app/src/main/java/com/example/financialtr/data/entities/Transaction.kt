package com.example.financialtr.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.financialtr.data.entities.User
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.data.enums.TransactionType

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["user_id"],
            onDelete = ForeignKey.Companion.CASCADE
        )
    ],
    indices = [
        Index(value = ["user_id"]),
        Index(value = ["category_id"]),
        Index(value = ["type_id"])
    ]
)
data class Transaction (
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    @ColumnInfo(name = "user_id")
    val userId: Int,

    @ColumnInfo(name = "type_id")
    val type: TransactionType? = null,

    @ColumnInfo(name = "category_id")
    val category: TransactionCategory? = null,

    var date: Long,
    var amount: Double,
    var comment: String
){
    @ColumnInfo(name = "type_ordinal")
    var typeOrdinal: Int? = type?.ordinal

    @ColumnInfo(name = "category_ordinal")
    var categoryOrdinal: Int? = category?.ordinal
}