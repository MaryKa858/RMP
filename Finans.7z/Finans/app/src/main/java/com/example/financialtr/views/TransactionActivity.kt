package com.example.financialtr.views


import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.financialtr.databinding.ActivityTransactionsBinding
import com.example.financialtr.data.enums.TransactionType
import com.example.financialtr.adapters.TransactionsAdapter
import com.example.financialtr.data.AppDatabase
import com.example.financialtr.data.entities.Transaction
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.viewModels.TransactionsViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class TransactionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTransactionsBinding
    private lateinit var viewModel: TransactionsViewModel
    private lateinit var adapter: TransactionsAdapter
    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionsBinding.inflate(layoutInflater)
        sharedPref = getSharedPreferences("auth", MODE_PRIVATE)
        setContentView(binding.root)

        val dao = AppDatabase.getDatabase(this).transactionDao()
        val userId = getUserId()
        viewModel = TransactionsViewModel(dao, userId)
        adapter = TransactionsAdapter { transaction ->
            onTransactionClick(transaction)
        }

        setupRecyclerView()
        setupTabs()
        setupSortButton()
        setupCategoryFilter()
        setupSearch()
        observeTransactions()
    }

    private fun getUserId(): Int {
        return sharedPref.getInt("user_id", -1)
    }

    private fun setupRecyclerView() {
        binding.recyclerViewTransactions.apply {
            layoutManager = LinearLayoutManager(this@TransactionsActivity)
            adapter = this@TransactionsActivity.adapter
        }
    }

    private fun setupSortButton() {
        binding.sortTransaction.setOnClickListener {
            showSortDialog()
        }
    }

    private fun setupCategoryFilter() {
        updateCategories(TransactionCategory.getAllCategories())

        binding.spinnerCategory.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val categories = listOf("Все категории") + TransactionCategory.getAllCategories()
            val category = if (position == 0) null else categories[position]
            viewModel.setCategoryFilter(category)
        }
    }

    private fun updateCategories(categories: List<String>) {
        val allCategories = listOf("Все категории") + categories
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            allCategories
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.spinnerCategory.setAdapter(adapter)
        binding.spinnerCategory.setText("Все категории", false)
    }

    private fun setupSearch() {
        binding.searchComment.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                viewModel.setSearchQuery(s.toString())
            }
        })
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> viewModel.setFilter(null)
                    1 -> viewModel.setFilter(TransactionType.INCOME)
                    2 -> viewModel.setFilter(TransactionType.EXPENSE)
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }


    private fun observeTransactions() {
        lifecycleScope.launch {
            viewModel.transactions.collectLatest { transactions ->
                adapter.submitList(transactions)
            }
        }
    }

    private fun onTransactionClick(transaction: Transaction) {
//        val intent = Intent(this, TransactionDetailsActivity::class.java).apply {
//            putExtra("TRANSACTION_ID", transaction.id)
//        }
//        startActivity(intent)
    }

    private fun showSortDialog() {
        val items = arrayOf(
            "По дате (новые сначала)",
            "По дате (старые сначала)",
        )

        MaterialAlertDialogBuilder(this)
            .setTitle("Сортировка")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> viewModel.setSortOrder(TransactionsViewModel.SortOrder.DATE_DESC)
                    1 -> viewModel.setSortOrder(TransactionsViewModel.SortOrder.DATE_ASC)
                }
            }
            .show()
    }
}