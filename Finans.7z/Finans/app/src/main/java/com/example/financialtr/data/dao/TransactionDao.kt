package com.example.financialtr.data.dao

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.financialtr.data.entities.Transaction
import kotlinx.coroutines.flow.Flow
import com.example.financialtr.data.enums.TransactionType

@Dao
interface TransactionDao {
    @Insert
    suspend fun insert(transaction: Transaction)

    @Insert
    suspend fun insertAll(vararg transactions: Transaction)


    @Query("SELECT * FROM transactions WHERE user_id = :userId ORDER BY date DESC")
    fun getTransactionsByUser(userId: Int): Flow<List<Transaction>>

    @Query("""
        SELECT
            COALESCE(SUM(CASE WHEN type_id = 0  THEN amount ELSE 0 END), 0.0) AS income,
            COALESCE(SUM(CASE WHEN type_id = 1 THEN amount ELSE 0 END), 0.0) AS expense
        FROM transactions
        WHERE user_id = :userId
    """)
    suspend fun getIncomeAndExpense(userId: Int): IncomeExpense


    @Query("""
        SELECT COALESCE(SUM(amount), 0) 
        FROM transactions 
        WHERE user_id = :userId 
        AND type_id = 0 
        AND date BETWEEN :startDate AND :endDate
    """)
    fun getIncomeBetweenDates(userId: Int, startDate: Long, endDate: Long): Flow<Double>

    @Query("""
        SELECT COALESCE(SUM(amount), 0) 
        FROM transactions 
        WHERE user_id = :userId 
        AND type_id = 1 
        AND date BETWEEN :startDate AND :endDate
    """)
    fun getExpenseBetweenDates(userId: Int, startDate: Long, endDate: Long): Flow<Double>

    @Query("""
    SELECT category_id, COALESCE(SUM(amount), 0) as total 
    FROM transactions 
    WHERE user_id = :userId 
    AND type_id = 1 
    AND date BETWEEN :startDate AND :endDate
    GROUP BY category_id
""")
    fun getExpenseByCategoryBetweenDates(
        userId: Int,
        startDate: Long,
        endDate: Long
    ): Flow<List<CategoryAmount>>

    @Query("""
        SELECT date, 
               COALESCE(SUM(CASE WHEN type_id = 0 THEN amount ELSE 0 END), 0) as income,
               COALESCE(SUM(CASE WHEN type_id = 1 THEN amount ELSE 0 END), 0) as expense
        FROM transactions
        WHERE user_id = :userId
        AND date BETWEEN :startDate AND :endDate
        GROUP BY date
        ORDER BY date ASC
    """)
    fun getDailyStatsBetweenDates(userId: Int, startDate: Long, endDate: Long): Flow<List<DailyStats>>
}

data class IncomeExpense(
    val income: Double,
    val expense: Double
)


data class DailyStats(
    @ColumnInfo(name = "date") val date: Long,
    @ColumnInfo(name = "income") val income: Double,
    @ColumnInfo(name = "expense") val expense: Double
)

data class CategoryAmount(
    @ColumnInfo(name = "category_id") val categoryId: Int,
    @ColumnInfo(name = "total") val amount: Double
)