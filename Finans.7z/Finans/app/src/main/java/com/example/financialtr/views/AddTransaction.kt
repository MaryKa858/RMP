package com.example.financialtr.views

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.financialtr.R
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.data.enums.TransactionType
import com.example.financialtr.viewModels.TransactionViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddTransaction : AppCompatActivity() {
    private val viewModel: TransactionViewModel by viewModels()
    private lateinit var sharedPref: SharedPreferences
    private lateinit var homeScreen: Button
    private lateinit var commit: Button
    private lateinit var spinner: Spinner
    private lateinit var etamount: EditText
    private lateinit var etdate: EditText
    private lateinit var etcomment: EditText
    private lateinit var radioGroup: RadioGroup


    fun getSelectedType(): TransactionType? {
        return when (radioGroup.checkedRadioButtonId) {
            R.id.rbincome -> TransactionType.INCOME
            R.id.rbexpence -> TransactionType.EXPENSE
            else -> null
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_transaction)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        sharedPref = getSharedPreferences("auth", MODE_PRIVATE)
        val userId = sharedPref.getInt("user_id", -1)
        spinner = findViewById<Spinner>(R.id.spCategory)
        etamount = findViewById<EditText>(R.id.etAmount)
        etdate = findViewById<EditText>(R.id.etDate)
        etcomment = findViewById<EditText>(R.id.etComment)
        homeScreen = findViewById<Button>(R.id.btnBack)
        commit = findViewById<Button>(R.id.btnCommit)
        radioGroup = findViewById<RadioGroup>(R.id.radioGroup)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            TransactionCategory.getAll()
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        spinner.adapter = adapter

        homeScreen.setOnClickListener {
            startActivity(Intent(this, HomeScreen::class.java))
            finish()
        }
        commit.setOnClickListener {
            val type = getSelectedType()
            if (type!=null)
            {
                CoroutineScope(Dispatchers.Main).launch {
                    if (etamount.text.isNotEmpty() and etdate.text.isNotEmpty() and (spinner.selectedItemPosition >= 0)) {
                        val selectedCategory =
                            TransactionCategory.values()[spinner.selectedItemPosition]
                        val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                        val date = sdf.parse(etdate.text.toString())?.time ?: 0L

                        if (viewModel.addTransaction(
                                type = type, category = selectedCategory,
                                date = date,
                                amount = etamount.text.toString().toDouble(),
                                comment = etcomment.text.toString(),
                                userId = userId
                            )
                        ) {
                            Toast.makeText(
                                this@AddTransaction,
                                "Запись успешно добавлена",
                                Toast.LENGTH_SHORT
                            ).show()
                            etamount.text.clear()
                            etdate.text.clear()
                            etcomment.text.clear()
                        } else {
                            Toast.makeText(
                                this@AddTransaction,
                                "Возникли ошибки при добавлении записи",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    }
                    else
                    {Toast.makeText(this@AddTransaction, "Не все поля заполнены", Toast.LENGTH_SHORT).show()}
                }

            }
            else
            {Toast.makeText(this@AddTransaction, "Не выбран тип транзакции", Toast.LENGTH_SHORT).show()}


        }

    }
}