package com.example.financialtr.views

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.financialtr.R
import com.example.financialtr.viewModels.MainViewModel

class LoginAvtivity : AppCompatActivity() {
    private val viewModel: MainViewModel by viewModels ()
    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login_avtivity)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val linkToReg = findViewById<TextView>(R.id.linkToRegistration)
        linkToReg.setOnClickListener {
            var intent = Intent(this, RegActivity::class.java)
            startActivity(intent)
        }


        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            val email = findViewById<EditText>(R.id.logEmail).text.toString()
            val password = findViewById<EditText>(R.id.logPassword).text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                viewModel.login(email, password)
            } else {
                Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show()
            }

        }

        sharedPref = getSharedPreferences("auth", MODE_PRIVATE)
        viewModel.loginResult.observe(this) { userId ->
            userId?.let {
                sharedPref.edit()
                    .putInt("user_id", userId)
                    .apply()
                startActivity(Intent(this, HomeScreen::class.java))
                finish()
            }

        }

        viewModel.error.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }


    }
}