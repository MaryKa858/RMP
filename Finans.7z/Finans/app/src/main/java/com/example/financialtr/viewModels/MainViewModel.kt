package com.example.financialtr.viewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.financialtr.App
import com.example.financialtr.data.AppDatabase
import com.example.financialtr.data.entities.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val dao = db.userDao()

    val users: LiveData<List<User>> = dao.getAllUsers()
    suspend fun registerUser(email: String, password: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val user = User(email = email, password = password)
                dao.insert(user)
                true
            } catch (e: Exception) {
                false
            }


        }
    }

    private val _loginResult = MutableLiveData<Int?>()
    val loginResult: LiveData<Int?> = _loginResult

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun login(email: String, password: String) {
        viewModelScope.launch {
            try {
                val userId = dao.findUser(email, password)
                _loginResult.postValue(userId)
            } catch (e: Exception) {
                _error.postValue("Ошибка: ${e.message}")
            }
        }
    }
}