package com.example.financialtr.viewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.financialtr.data.entities.Transaction
import kotlinx.coroutines.Dispatchers
import androidx.lifecycle.viewModelScope
import com.example.financialtr.App
import com.example.financialtr.data.AppDatabase
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.data.enums.TransactionType
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TransactionViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val dao = db.transactionDao()

    private val _amounts = MutableLiveData<List<Double>>()
    val amounts: LiveData<List<Double>> = _amounts

    fun loadAmounts(userId: Int) {
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    dao.getIncomeAndExpense(userId)
                }
                _amounts.postValue(listOf(result.income, result.expense))
            } catch (e: Exception) {
                _amounts.postValue(listOf(0.0, 0.0))
            }
        }
    }

    suspend fun addTransaction(
        type: TransactionType,
        category: TransactionCategory,
        date: Long,
        amount: Double,
        comment: String,
        userId: Int
    ): Boolean {
        return try {
            val transaction = Transaction(
                type = type,
                category = category,
                date = date,
                amount = amount,
                comment = comment,
                userId = userId
            )
            withContext(Dispatchers.IO) {
                dao.insert(transaction)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}