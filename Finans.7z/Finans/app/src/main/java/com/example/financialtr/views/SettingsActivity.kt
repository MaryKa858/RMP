package com.example.financialtr.views

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import com.example.financialtr.R
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var themeSwitch: Switch
    private lateinit var logoutButton: Button
    private lateinit var versionTextView: TextView

    private val PREFS_NAME = "MyPrefs"
    private val THEME_KEY = "theme"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        initViews()
        initSharedPreferences()
        setupThemeSwitch()
        setupAppVersion()
        setupLogoutButton()
    }

    private fun initViews() {
        themeSwitch = findViewById(R.id.themeSwitch)
        logoutButton = findViewById(R.id.logoutButton)
        versionTextView = findViewById(R.id.versionTextView)
    }

    private fun initSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private fun setupThemeSwitch() {
        val isDarkTheme = sharedPreferences.getBoolean(THEME_KEY, false)
        themeSwitch.isChecked = isDarkTheme

        themeSwitch.setOnCheckedChangeListener { _, isChecked ->
            saveThemePreference(isChecked)
            applyTheme(isChecked)
        }
    }

    @SuppressLint("CommitPrefEdits")
    private fun setupLogoutButton() {
        logoutButton.setOnClickListener {
            val intent = Intent(this, LoginAvtivity::class.java)
            sharedPreferences.edit().remove("user_id")

            startActivity(Intent(this, HomeScreen::class.java))
            finish()
            startActivity(intent)
            finish()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setupAppVersion() {
        versionTextView.setText("Версия: ${getAppVersion()}")
    }

    private fun getAppVersion(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "1.0"
        }.toString()
    }

    private fun saveThemePreference(isDarkTheme: Boolean) {
        sharedPreferences.edit().putBoolean(THEME_KEY, isDarkTheme).apply()
    }

    private fun applyTheme(isDarkTheme: Boolean) {
        AppCompatDelegate.setDefaultNightMode(
            if (isDarkTheme) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
        recreate()
    }
}