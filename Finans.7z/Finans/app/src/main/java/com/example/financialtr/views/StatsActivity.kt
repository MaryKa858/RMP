package com.example.financialtr.views

import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import java.text.SimpleDateFormat
import com.example.financialtr.R
import com.example.financialtr.data.AppDatabase
import com.example.financialtr.viewModels.StatisticsViewModel
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import java.util.*
import kotlin.math.abs

class StatisticsActivity : AppCompatActivity() {

    private lateinit var viewModel: StatisticsViewModel
    private lateinit var dateFormat: SimpleDateFormat
    private lateinit var sharedPref: SharedPreferences


    // Views
    private lateinit var incomeTextView: TextView
    private lateinit var expenseTextView: TextView
    private lateinit var balanceTextView: TextView
    private lateinit var pieChart: PieChart
    private lateinit var lineChart: LineChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPref = getSharedPreferences("auth", MODE_PRIVATE)
        setContentView(R.layout.activity_stats)

        val dao = AppDatabase.getDatabase(this).transactionDao()
        val userId = getUserId()
        viewModel = StatisticsViewModel(dao, userId)

        dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

        initViews()
        setupPeriodToggle()
        setupCharts()
        observeData()
    }

    private fun getUserId(): Int {
        return sharedPref.getInt("user_id", -1)
    }


    private fun initViews() {
        incomeTextView = findViewById(R.id.incomeTextView)
        expenseTextView = findViewById(R.id.expenseTextView)
        balanceTextView = findViewById(R.id.balanceTextView)
        pieChart = findViewById(R.id.pieChart)
        lineChart = findViewById(R.id.lineChart)
    }

    private fun setupPeriodToggle() {
        val toggleGroup = findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.periodToggleGroup)
        toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                when (checkedId) {
                    R.id.weekButton -> viewModel.setPeriod(StatisticsViewModel.Period.WEEK)
                    R.id.monthButton -> viewModel.setPeriod(StatisticsViewModel.Period.MONTH)
                    R.id.yearButton -> viewModel.setPeriod(StatisticsViewModel.Period.YEAR)
                }
            }
        }
    }

    private fun setupCharts() {
        // Настройка круговой диаграммы
        with(pieChart) {
            setUsePercentValues(true)
            description.isEnabled = false
            isDrawHoleEnabled = true
            holeRadius = 40f
            setExtraOffsets(5f, 10f, 5f, 5f)
            setEntryLabelColor(Color.BLACK)
            legend.isEnabled = false
        }

        // Настройка линейного графика
        with(lineChart) {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            legend.isEnabled = true

            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.granularity = 1f
            xAxis.setDrawGridLines(false)

            axisLeft.setDrawGridLines(true)
            axisRight.isEnabled = false
        }
    }

    private fun observeData() {
        viewModel.statsData.observe(this) { data ->
            updateSummary(data.income, data.expense)
            updatePieChart(data.expenseByCategory)
            updateLineChart(data.dailyData)
        }
    }

    private fun updateSummary(income: Double, expense: Double) {
        incomeTextView.text = formatAmount(income)
        expenseTextView.text = formatAmount(expense)
        balanceTextView.text = formatAmount(income - expense)
    }

    private fun updatePieChart(expenseByCategory: Map<String, Double>) {
        val entries = expenseByCategory.map {
            PieEntry(it.value.toFloat(), it.key)
        }

        val dataSet = PieDataSet(entries, "").apply {
            colors = getPieChartColors()
            valueTextSize = 12f
            valueTextColor = Color.WHITE
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return formatAmount(value.toDouble())
                }
            }
        }

        pieChart.data = PieData(dataSet)
        pieChart.invalidate()
    }

    private fun updateLineChart(dailyData: List<StatisticsViewModel.DailyData>) {
        val dates = dailyData.map { dateFormat.format(it.date) }
        val incomeEntries = dailyData.mapIndexed { index, data ->
            Entry(index.toFloat(), data.income.toFloat())
        }
        val expenseEntries = dailyData.mapIndexed { index, data ->
            Entry(index.toFloat(), abs(data.expense).toFloat())
        }

        val incomeDataSet = LineDataSet(incomeEntries, "Доходы").apply {
            color = Color.GREEN
            lineWidth = 2f
            setCircleColor(Color.GREEN)
            circleRadius = 4f
            valueTextSize = 10f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return formatAmount(value.toDouble())
                }
            }
        }

        val expenseDataSet = LineDataSet(expenseEntries, "Расходы").apply {
            color = Color.RED
            lineWidth = 2f
            setCircleColor(Color.RED)
            circleRadius = 4f
            valueTextSize = 10f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return formatAmount(value.toDouble())
                }
            }
        }

        lineChart.xAxis.valueFormatter = IndexAxisValueFormatter(dates)
        lineChart.data = LineData(incomeDataSet, expenseDataSet)
        lineChart.invalidate()
    }

    private fun getPieChartColors(): List<Int> {
        return listOf(
            Color.parseColor("#7AE981"),
            Color.parseColor("#FF7B8B"),
            Color.parseColor("#FFCE56"),
            Color.parseColor("#4BC0C0"),
            Color.parseColor("#9966FF"),
            Color.parseColor("#FF9F40")
        )
    }

    private fun formatAmount(amount: Double): String {
        return String.format(Locale.getDefault(), "%.2f ₽", amount)
    }
}