package com.example.financialtr.utils

import java.text.SimpleDateFormat
import java.util.*

fun formatDate(date: Date): String {
    val pattern = "dd MMM yyyy"
    val formatter = SimpleDateFormat(pattern, Locale.getDefault())
    return formatter.format(date)
}

fun formatAmount(amount: Double): String {
    return String.format(Locale.getDefault(), "%.2f ₽", amount)
}