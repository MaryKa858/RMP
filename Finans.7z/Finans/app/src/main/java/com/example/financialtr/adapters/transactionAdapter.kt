package com.example.financialtr.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.financialtr.databinding.ItemTransactionBinding
import com.example.financialtr.data.entities.Transaction
import com.example.financialtr.data.enums.TransactionType
import com.example.financialtr.utils.formatAmount
import com.example.financialtr.utils.formatDate
import com.example.financialtr.R
import java.util.*

class TransactionsAdapter(
    private val onItemClick: (Transaction) -> Unit
) : ListAdapter<Transaction, TransactionsAdapter.TransactionViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TransactionViewHolder(binding, onItemClick)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class TransactionViewHolder(
        private val binding: ItemTransactionBinding,
        private val onItemClick: (Transaction) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(transaction: Transaction) {
            with(binding) {
                textViewCategory.text = transaction.category?.name ?: "Без категории"
                textViewDate.text = formatDate(Date(transaction.date))

                val amountText = formatAmount(transaction.amount)
                textViewAmount.text = when (transaction.type) {
                    TransactionType.INCOME -> "+$amountText"
                    TransactionType.EXPENSE -> "-$amountText"
                    else -> amountText
                }

                val colorRes = when (transaction.type) {
                    TransactionType.INCOME -> R.color.green
                    TransactionType.EXPENSE -> R.color.red
                    else -> android.R.color.black
                }
                textViewAmount.setTextColor(root.context.getColor(colorRes))

                root.setOnClickListener { onItemClick(transaction) }
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Transaction>() {
        override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
            return oldItem == newItem
        }
    }
}