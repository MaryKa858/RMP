package com.example.financialtr.data.enums

enum class TransactionCategory(
    val title: String,
    val type: TransactionType
) {
    SALARY("Зарплата", TransactionType.INCOME),
    BONUS("Премия", TransactionType.INCOME),
    FOOD("Продукты", TransactionType.EXPENSE),
    TRANSPORT("Транспорт", TransactionType.EXPENSE);

    companion object {
        fun getAllCategories(): List<String> {
            return values().map { it.title }
        }

        fun getIncomeCategories(): List<String> {
            return values().filter { it.type == TransactionType.INCOME }.map { it.title }
        }

        fun getExpenseCategories(): List<String> {
            return values().filter { it.type == TransactionType.EXPENSE }.map { it.title }
        }
        fun getAll(): Array<String> {
            return values().map { it.title}.toTypedArray()
        }

    }

}