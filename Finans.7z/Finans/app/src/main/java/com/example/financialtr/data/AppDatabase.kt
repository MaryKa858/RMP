package com.example.financialtr.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.financialtr.data.dao.TransactionDao
import com.example.financialtr.data.dao.UserDao
import com.example.financialtr.data.entities.Transaction
import com.example.financialtr.data.entities.User

@Database(
    entities = [
        User::class,
        Transaction::class
    ],
    version = 1
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        private var instance: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context,
                    AppDatabase::class.java,
                    "financial_db"
                ).build().also { instance = it }
            }
        }
    }
}
