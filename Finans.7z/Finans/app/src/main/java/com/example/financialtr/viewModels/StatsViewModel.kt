package com.example.financialtr.viewModels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.financialtr.data.dao.CategoryAmount
import com.example.financialtr.data.dao.TransactionDao
import kotlinx.coroutines.flow.*
import java.util.*

class StatisticsViewModel(private val dao: TransactionDao, private val userId: Int) : ViewModel() {

    private val _period = MutableStateFlow(Period.WEEK)

    val statsData: LiveData<StatsData> = _period.flatMapLatest { period ->
        when (period) {
            Period.WEEK -> getWeeklyStats()
            Period.MONTH -> getMonthlyStats()
            Period.YEAR -> getYearlyStats()
        }
    }.asLiveData()

    fun setPeriod(period: Period) {
        _period.value = period
    }

    private fun getWeeklyStats(): Flow<StatsData> {
        val calendar = Calendar.getInstance()
        val endDate = calendar.timeInMillis
        calendar.add(Calendar.DAY_OF_YEAR, -7)
        val startDate = calendar.timeInMillis

        return getStatsForPeriod(startDate, endDate)
    }

    private fun getMonthlyStats(): Flow<StatsData> {
        val calendar = Calendar.getInstance()
        val endDate = calendar.timeInMillis
        calendar.add(Calendar.MONTH, -1)
        val startDate = calendar.timeInMillis

        return getStatsForPeriod(startDate, endDate)
    }

    private fun getYearlyStats(): Flow<StatsData> {
        val calendar = Calendar.getInstance()
        val endDate = calendar.timeInMillis
        calendar.add(Calendar.YEAR, -1)
        val startDate = calendar.timeInMillis

        return getStatsForPeriod(startDate, endDate)
    }

    private fun getStatsForPeriod(startDate: Long, endDate: Long): Flow<StatsData> {
        return combine(
            dao.getIncomeBetweenDates(userId, startDate, endDate),
            dao.getExpenseBetweenDates(userId, startDate, endDate),
            dao.getExpenseByCategoryBetweenDates(userId, startDate, endDate),
            dao.getDailyStatsBetweenDates(userId, startDate, endDate)
        ) { income, expense, categoryAmounts, dailyStats ->
            StatsData(
                income = income,
                expense = expense,
                expenseByCategory = categoryAmounts.associate {
                    it.categoryId.toString() to it.amount
                },
                dailyData = dailyStats.map {
                    DailyData(
                        date = Date(it.date),
                        income = it.income,
                        expense = it.expense
                    )
                }
            )
        }
    }

    data class StatsData(
        val income: Double,
        val expense: Double,
        val expenseByCategory: Map<String, Double>,
        val dailyData: List<DailyData>
    )

    data class DailyData(
        val date: Date,
        val income: Double,
        val expense: Double
    )

    enum class Period { WEEK, MONTH, YEAR }
}
