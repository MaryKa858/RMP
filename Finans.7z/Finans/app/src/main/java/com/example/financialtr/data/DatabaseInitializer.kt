package com.example.financialtr.data

import com.example.financialtr.data.entities.*
import com.example.financialtr.data.enums.TransactionCategory
import com.example.financialtr.data.enums.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DatabaseInitializer(private val db: AppDatabase) {

    suspend fun initData() = withContext(Dispatchers.IO) {
        if (db.userDao().getUserCount() == 0) {
            val userId = db.userDao().insert(
                User(
                    email = "user@example.com",
                    password = "1"
                )
            ).toInt()

            val currentTime = System.currentTimeMillis()
            db.transactionDao().insertAll(
                Transaction(
                    userId = userId,
                    type = TransactionType.INCOME,
                    category = TransactionCategory.SALARY,
                    date = currentTime - 86400000 * 2,
                    amount = 1500.0,
                    comment = "Коммент 1"
                ),

                Transaction(
                    userId = userId,
                    type = TransactionType.EXPENSE,
                    category = TransactionCategory.FOOD,
                    date = currentTime - 86400000,
                    amount = -125.50,
                    comment = "Коммент 2"
                ),

                Transaction(
                    userId = userId,
                    type = TransactionType.EXPENSE,
                    category = TransactionCategory.TRANSPORT,
                    date = currentTime,
                    amount = -75.30,
                    comment = "Коммент 3"
                )
            )
        }
    }
}